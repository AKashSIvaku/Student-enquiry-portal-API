# 2bc0e094-fbdd-4be3-ab54-f6115d1484f5-3ee4b13d-9fc7-406b-aa11-9c0e75b5e702
Repository for Teams Project code and project management
